package io.github.metin.dosyasifreleyici;

import io.github.metin.dosyasifreleyici.Frame.Uygulama;


// Uygulamanın giriş noktası
public class Main {

    // Uygulamayı başlatır
    public static void main(String[] args) throws Exception {
        // Uygulama sınıfını başlatır
        new Uygulama();
    }
}